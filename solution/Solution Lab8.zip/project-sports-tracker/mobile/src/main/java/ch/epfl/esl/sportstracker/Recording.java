package ch.epfl.esl.sportstracker;

public class Recording {
    protected String exerciseType;
    protected long exerciseDateTime;
    protected boolean exerciseSmartWatch;
    protected boolean exerciseHRbelt;
}
