package ch.epfl.esl.sportstracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button rButton = findViewById(R.id.RegisterButton);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView mTextView = findViewById(R.id.LoginMessage);
                mTextView.setText("We used the Java callback");
            }
        });
    }

    public void clickedLoginButtonXmlCallback(View view) {
        TextView mTextView = findViewById(R.id.LoginMessage);
        mTextView.setText("We used the XML callback");
    }
}
